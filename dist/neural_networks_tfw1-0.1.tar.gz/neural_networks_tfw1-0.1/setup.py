from setuptools import setup

setup(name='neural_networks_tfw1',
      version='0.1',
      description='Implementing Neural Networks with Tensorflow',
      packages=['neural_networks_tfw1'],
      author='Dilay Fidan Ercelik',
      author_email='dilay.ercelik@gmail.com',
      zip_safe=False)
